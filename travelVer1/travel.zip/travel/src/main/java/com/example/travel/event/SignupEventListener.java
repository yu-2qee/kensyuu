package com.example.travel.event;

import java.util.UUID;

import org.springframework.context.event.EventListener;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.example.travel.entity.User;
import com.example.travel.service.VerificationTokenService;
@Component
public class SignupEventListener {
private final VerificationTokenService verificationTokenService;
private final JavaMailSender javaMailSender;
public SignupEventListener(VerificationTokenService verificationTokenService, JavaMailSender mailSender) {
this.verificationTokenService = verificationTokenService;
this.javaMailSender = mailSender;
}
@EventListener
private void onSignupEvent(SignupEvent signupEvent) {
	User user= signupEvent.getUser();
	String token=UUID.randomUUID().toString();
	verificationTokenService.create(user, token);
	String recipientAddress = user.getEmail();
	String subject="メール認証";
	String confirmationUrl=signupEvent.getRequestUrl()+"/verify?token="+token;
	String message="以下のリンクをクリックしてください";
	SimpleMailMessage mailMessage=new SimpleMailMessage();
	mailMessage.setTo(recipientAddress);
	mailMessage.setSubject(subject);
	mailMessage.setText(message+"\n"+confirmationUrl);
	javaMailSender.send(mailMessage);
	
}
}

