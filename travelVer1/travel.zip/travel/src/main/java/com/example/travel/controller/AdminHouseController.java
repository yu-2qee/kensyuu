package com.example.travel.controller;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.travel.entity.House;
import com.example.travel.form.HouseEditForm;
import com.example.travel.form.HouseRegisterForm;
import com.example.travel.repository.HouseRepository;
import com.example.travel.service.HouseService;


@Controller

@RequestMapping("admin/houses")

public class AdminHouseController {
private final HouseRepository houseRepository;
private final HouseService houseService;
public AdminHouseController(HouseRepository houseRepository,HouseService houseService) {
	this.houseService=houseService;
	this.houseRepository=houseRepository;

}


//@GetMapping
//public String index(Model model,Pageable pageable){
//	Page<House>housePage=houseRepository.findAll(pageable);
//	model.addAttribute("housePage",housePage);
//	return"admin/houses/index";}


@GetMapping
public String index(Model model,
@PageableDefault
(page = 0, size = 10, sort = "id", direction = Direction.ASC) Pageable pageable,	
@RequestParam(name="keyword",required = false)String keyword){
	Page<House>housePage;
	if(keyword!=null&&!keyword.isEmpty()) {
		housePage = houseRepository.findByNameLike("%" + keyword + "%", pageable);
	}else {
		housePage=houseRepository.findAll(pageable);
	}
	model.addAttribute("housePage",housePage);
	model.addAttribute("keyword", keyword);
	
	return "admin/houses/index";
}

@GetMapping("/{id}")
public String show(@PathVariable(name="id")Integer id,Model model) {
	House house=houseRepository.getReferenceById(id);
	model.addAttribute("house",house);
    return "admin/houses/show";
}

@GetMapping("/register")
public String register(Model model) {
	model.addAttribute("houseRegisterForm",new HouseRegisterForm());
	return "admin/houses/register";
}
@PostMapping("/create")

public String create(@ModelAttribute @Validated HouseRegisterForm houseRegisterForm,
		BindingResult bindingResult,org.springframework.web.servlet.mvc.support.RedirectAttributes redirectAttributes) {
	if(bindingResult.hasErrors()) {
		return "admin/houses/register";
	}
	houseService.create(houseRegisterForm);
	redirectAttributes.addFlashAttribute("successmessage","民宿を登録しました。")	;
	return "redirect:/admin/houses";
}
@GetMapping("/{id}/edit")

public String edit(@PathVariable(name = "id") Integer id, Model model) {
House house = houseRepository.getReferenceById(id);
String imageName = house.getImageName();
HouseEditForm houseEditForm = new HouseEditForm(house.getId(), house.getName(), null,
house.getDescription(), house.getPrice(), house.getCapacity(),
house.getPostalCode(), house.getAddress(), house.getPhoneNumber());
model.addAttribute("imageName", imageName);
model.addAttribute("houseEditForm", houseEditForm);
return "admin/houses/edit";
}

@PostMapping("/{id}/update")
public  String update(@ModelAttribute @Validated HouseEditForm houseEditForm,
		BindingResult bindingResult,RedirectAttributes rediretAtributes) {

	if (bindingResult.hasErrors()) {
        return "admin/houses/edit";
    }
	houseService.update(houseEditForm);
	rediretAtributes.addFlashAttribute("successMessage","民宿を編集しました。")	;
	return "redirect:/admin/houses";			
}
@PostMapping("/{id}/delete")
public String delete(@PathVariable(name="id")Integer id,RedirectAttributes redirectAttributes){
   houseRepository.deleteById(id);
   redirectAttributes.addFlashAttribute("successMessage","民宿を削除しました");  
    return "redirect:/admin/houses";
}
}
				